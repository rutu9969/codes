package com.capgemini.test.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.AccountHolder;
import com.capgemini.test.bean.Transaction;
import com.capgemini.test.exception.RecordNotFoundException;

public class DaoClass implements DaoInterface{
	Transaction[] txns;
	int idx;
	double amount;
	AccountHolder holder=new AccountHolder();
	private Map<Integer,AccountHolder> map=new HashMap<>();
	public Map<Integer,Double> balance=new HashMap<>();

	
	//	To get auto generated account number and storing details
	public void storeIntoMap(AccountHolder holder) {
		double accountNumber=Math.random()*10000;
		holder.setAccountNumber((int)accountNumber);
		txns=new Transaction[10];
		txns[idx++]=new Transaction("CR",amount,holder.getAccountBalance());
		
	}
	
//	To print all the details of holder in map
	public Map<Integer,AccountHolder> displayHolderdetails() {
		return map;
	}
 
	
	//To deposit the amount in specific account
	@Override
	public void deposit(double amount){
		holder.setAccountBalance((holder.getAccountBalance()+amount));
		balance.put(holder.getAccountNumber(), holder.getAccountBalance());
		txns[idx++]=new Transaction("CR",amount,holder.getAccountBalance());
		
	}
//   To show how much balance is available in account
	@Override
	public double showBalance() {
		
		return (holder.getAccountBalance());		
	}
// To withdraw amount from an account
	@Override
	public void withdraw(double amount) {
		if(amount<=holder.getAccountBalance()){
			holder.setAccountBalance(holder.getAccountBalance()-amount);
			balance.put(holder.getAccountNumber(), holder.getAccountBalance());
			txns[idx++]=new Transaction("WD",amount,holder.getAccountBalance());
		}
		else
			System.out.println("SORRY \nInsufficient Balance in your account");
		
	}
//To transfer fundamount from one account into another
	@Override
	public void fundTransfer(double amount) {
		
		if(amount<=holder.getAccountBalance()){
			holder.setAccountBalance(holder.getAccountBalance()-amount);
			balance.put(holder.getAccountNumber(), holder.getAccountBalance());
			txns[idx++]=new Transaction("FT",amount,holder.getAccountBalance());
		}else
			System.out.println("SORRY \n Insufficient Balance in your account");
		
	}

	@Override
	public void printTransaction() {
for(int i=0;i<idx;i++)
	System.out.println(txns[i].print());
	}

	public AccountHolder find(int id) {
		return null;
	}
	public AccountHolder find(long id) throws RecordNotFoundException
	{
		
		AccountHolder cust=map.get(id);
		if(cust!=null)
		return cust;
		else
			throw new RecordNotFoundException("Record not found");
		
	}
	

}
