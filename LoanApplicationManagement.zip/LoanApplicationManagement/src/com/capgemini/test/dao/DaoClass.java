package com.capgemini.test.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.exception.RecordNotFoundException;

public class DaoClass implements DaoInterface {
	private Map<Long,Customer> map=new HashMap<>();
	private Map<Double,Loan> map1=new HashMap<>();

	@Override
	public void storeIntoMap(Customer customer) {
		double customerId=Math.random()*100;
		customer.setCustId((long)customerId);
		map.put((long) customerId, customer);
		
	}
	
	public Map<Long,Customer>displayCustomer(){
		return map;
		
	}


	@Override
	public void applyLoan(Loan loan) {
		
		double loanId=Math.random()*100;
		loan.setLoanID((long)loanId);
		map1.put(loanId, loan);
	}
	public Customer find(long id) throws RecordNotFoundException
	{
		
		Customer cust=map.get(id);
		if(cust!=null)
		return cust;
		else
			throw new RecordNotFoundException("Record not found");
		
	}

	@Override
	public void insertCustomerDetail(Customer customer)
			throws RecordNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer findCustomerDetails(long custId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
