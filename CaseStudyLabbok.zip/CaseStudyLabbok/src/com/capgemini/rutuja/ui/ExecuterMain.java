package com.capgemini.rutuja.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.rutuja.service.ServiceClass;
import com.capgemini.rutuja.service.ServiceInterface;

public class ExecuterMain {
	
public static void main(String[] args) throws IOException {
	String id;
	String name;
	int salary;
		ServiceInterface service=new ServiceClass();
		boolean isValid;
		
	
		Scanner sc=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true){
		System.out.println("Enter your Id");
		id=sc.next();
		isValid=service.validateId(id);
		
		if(isValid)
			break;
		else
			System.out.println("Enter proper Id");
		}
		while(true){
			System.out.println("Enter your Name");
			name=br.readLine();
			isValid=service.validateName(name);
			
			if(isValid)
				break;
			else
				System.out.println("Enter proper Name");
			}
		System.out.println("Enter your salary ");
		salary=sc.nextInt();
		System.out.println("Your salary is: "+salary);
		service.salaryScheme(salary);
		
		
			
		
	}

}
