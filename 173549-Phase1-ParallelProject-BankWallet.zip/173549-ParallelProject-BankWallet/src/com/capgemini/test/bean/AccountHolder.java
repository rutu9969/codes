package com.capgemini.test.bean;

public class AccountHolder {
	private String holderName;
	private String holderAddress;
	private String holderMobile;
    private double accountBalance;
	private int accountNumber;
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getHolderAddress() {
		return holderAddress;
	}
	public void setHolderAddress(String holderAddress) {
		this.holderAddress = holderAddress;
	}
	public String getHolderMobile() {
		return holderMobile;
	}
	public void setHolderMobile(String holderMobile) {
		this.holderMobile = holderMobile;
	}
//	public int getHolderAge() {
//		return holderAge;
//	}
//	public void setHolderAge(int holderAge) {
//		this.holderAge = holderAge;
//	}
	
	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "AccountHolder [holderName=" + holderName + ", holderAddress="
				+ holderAddress + ", holderMobile=" + holderMobile
				+ ", accountNumber=" + accountNumber + "]";
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

}
