package com.capgemini.test.service;

import com.capgemini.test.bean.AccountHolder;

public interface ServiceInterface {
	String CHOICE_PATTERN="[1-2]{1}";
	boolean validateChoice(String choice);
	
	//Name pattern for validation
	String CUSTOMER_NAME_PATTERN="[A-Z][a-z]{1,9}";
	boolean validateCustomerName(String customerName);
	
//	Address pattern for validation
	String CUSTOMER_ADDRESS_PATTERN="[A-Z][a-z]{1,50}";
	boolean validateCustomerAddress(String customerAddress);
	
//	EmailId pattern for validation
	String CUSTOMER_EMAILID_PATTERN="[a-z]{1,20}[@]{1}[a-z]{1,10}[.]{1}[c,o,m]{3}";
	boolean validateCustomerEmailId(String customerEmailId);
	
//	Mobileno pattern for validation
	String CUSTOMER_MOBILE_NO_PATTERN="[7,8,9]{1}[1-9]{9}";
	
	
	boolean validateCustomerMobileNo(String customerMobileNo);
	void storeIntoMap(AccountHolder holder);
	double showBalance();
	void deposit(double amount);
	void withdraw(double amount);
	void fundTransfer(double amount);
	public void printsummary();

//	boolean validateChoice1(String choice1);

	

}
