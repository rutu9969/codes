package cg.service;

import cg.bean.LoginBean;

public interface ILoginService {
	boolean authenticate(LoginBean login);

}
