package com.capgemini.test.service;

import com.capgemini.test.bean.AccountHolder;
import com.capgemini.test.dao.DaoClass;
import com.capgemini.test.dao.DaoInterface;

public class ServiceClass implements ServiceInterface{
	DaoClass dao=new DaoClass();
		
		@Override
		public void storeIntoMap(AccountHolder holder) {
			dao.storeIntoMap(holder);
		}
	

	@Override
	public boolean validateChoice(String choice) {
		if(choice.matches(CHOICE_PATTERN))
		return true;
		else
		return false;
	}

	@Override
	public boolean validateCustomerName(String customerName) {
		

		if (customerName.matches(CUSTOMER_NAME_PATTERN))
			return true;
		else
			return false;

	}

	@Override
	public boolean validateCustomerAddress(String customerAddress) {
		if (customerAddress.matches(CUSTOMER_ADDRESS_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateCustomerEmailId(String customerEmailId) {
		if (customerEmailId.matches(CUSTOMER_EMAILID_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateCustomerMobileNo(String customerMobileNo) {
		if (customerMobileNo.matches(CUSTOMER_MOBILE_NO_PATTERN))
			return true;
		else
			return false;
	}

//  To call showbalance  method
   public double showBalance(){
	   
	return dao.showBalance();
   }
//   To call deposit method 
   public void deposit(double amount){
	   dao.deposit(amount);
   }
//   To call withdraw method
   public void withdraw(double amount){
	   dao.withdraw(amount);
   }


@Override
public void fundTransfer(double amount) {
dao.fundTransfer(amount);	
}


@Override
public void printsummary() {
	dao.printTransaction();
	
}





}
