package com.capgemini.mayuresh.service;


import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.mayuresh.bean.Account;
import com.capgemini.mayuresh.dao.StoreUserdata;
import com.capgemini.mayuresh.exception.BalanceException;
import com.capgemini.mayuresh.exception.RecordNotFoundException;

public class ValidateUserInput implements ValidateInterface {
	// StoreUserdata data = new StoreUserdata();// creating object for calling
	// DAO methods(storeToMap,displayDetails)
	StoreUserdata data = new StoreUserdata();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(MOBILE_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		else
			return false;
	}

	public boolean validateEntry(String ch) {
		if (ch.matches(ENTRY))
			return true;
		else
			return false;
	}

	public void openAccount(Account acc) {
		data.openAccount(acc);

	}

	@Override
	public boolean validateAccId(String userAccId) {
		if (userAccId.matches(ACC_NO))
			return true;
		else
			return false;
	}

	public double showBalance(int accId) throws RecordNotFoundException {
		return data.showBalance(accId);

	}

	public boolean validateAmount(String amount) {
		if (amount.matches(AMOUNT))
			return true;
		else
			return false;
	}

	@Override
	public void deposit(int accId, double amount) throws RecordNotFoundException {
	
			data.deposit(accId, amount);
		
	}

	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		data.Showtransaction(userAccId);
		
	}

	public void withdraw(int accId, double amount) throws BalanceException, RecordNotFoundException {
		
			data.withdraw(accId, amount);
		
	}

	public void fundTransfer(int source, int target, double amount) {
		try {
			data.fundTransfer(source,target,amount);
		} catch (BalanceException | RecordNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public boolean validatePassword(String password) {
		if (password.matches(PASSWORD))
			return true;
		else
			return false;
	}

	public Account validateUsernameAndPassword(String userName, String password) throws RecordNotFoundException {
		return data.validateUsernameAndPassword(userName, password);
	}
	public void createAccount() {
		boolean isValid;
		String name;
		String email;
		String mobile;
		String password;
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Bank Service");
		// System.out.println(userInput.validatePassword("Mayu123@"));
		while (true) {

			System.out.println("Enter name");
			name = sc.next();

			// to validate UserName
			isValid = validateUserName(name);
			if (isValid)
				break; // if user enter valid input then break
			else
				System.out
						.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
		}
		while (true) {

			System.out.println("Enter Email");
			email = sc.next();
			// to Validate User Email
			if(data.validateEmail(email)){
			isValid = validateEmail(email);
			if (isValid)
				break;// if user enter valid input then break
			else
				System.out
						.println("Please enter Valid Email(eg abc@gmail.com)");
			}else System.out.println("Email-Id No already exist");
		}
		while (true) {

			System.out.println("Enter mobile");
			mobile = sc.next();
			if(data.validateMobile(Long.parseLong(mobile))){
			// to validate user Mobile No
			isValid = validateMobile(mobile);
			if (isValid)
				break;// if user enter valid input then break
			else
				System.out
						.println("Please enter Valid Mobile without +91 (eg. 9167968584)");
			}else System.out.println("Mobile No already exist");
		}
		while (true) {
			System.out.println("Set Password");
			password = sc.next();
			// to validate user Mobile No
			isValid = validatePassword(password);
			if (isValid)
				break;// if user enter valid input then break
			else
				System.out
						.println("Please enter Valid password (eg. Mayuresh123@)");
		}
		 openAccount(new Account(name, Long.parseLong(mobile), email, password));

	}
}
