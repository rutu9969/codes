import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class SerializationDemo {
	public static void main(String[] args) throws Exception{
		Person p=new Person("polo",21);
		System.out.println(p);

		String path="newfile.txt";
		ObjectOutputStream ostream=null;
		ObjectInputStream istream=null;
		
		//serialization code
		ostream =new ObjectOutputStream(new FileOutputStream(path));
		ostream.writeObject(p);  //serializing object
		ostream.close();
		System.out.println("object serialized");
		
		//Deserialization code
		istream=new ObjectInputStream(new FileInputStream(path));
		Object obj=istream.readObject();  //Deserialization object
		System.out.println(obj);
		istream.close();
}

}
