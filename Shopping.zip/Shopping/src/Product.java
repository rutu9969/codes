
public abstract class Product {
	private int codeName;
	private String productName;
	private double price;
	private int stock;
	public double getPrice(){
		return price;
	}
	public Product(){
		
	}
	public  void updateStock(int quantity){
		stock=stock-quantity;
	}
	public Product(int codeName, String productName, double price, int stock) {
		super();
		this.codeName = codeName;
		this.productName = productName;
		this.price = price;
		this.stock = stock;
	}
	public int getStock() {
		return stock;
	}
	public  void productDiscription()
	{
		System.out.println("Code Name: "+codeName+"Product Name: "+productName+"Price: "+price+"Stock: "+stock);
		
	}
	
	
	

}
