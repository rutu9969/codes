import java.util.HashMap;
import java.util.Map;


public class ShoppingCart  {

	double total;
	Map<Product,Integer> cart=new HashMap<>();

	public void updateQuantity(Product product,int quantity) throws OutofStockException{
		removeItem(product);
		addItem(product,quantity);
	}
	
	public void addItem(Product product,int quantity) throws OutofStockException{
		if(quantity>=product.getStock()){
			throw new OutofStockException("Out of stock");
		}
		else{
		cart.put(product, quantity);
		product.updateStock(quantity);
		total+=product.getPrice()*quantity;
		}
	}
	public void removeItem(Product product) {
	
		int quantity= cart.get(product);
		cart.remove(product);
		product.updateStock(-quantity);
		total-=product.getPrice()*quantity;
	}
		
	public void checkout(){
		
		System.out.println("***Shopping cart summary****");
		
		for(Product product:cart.keySet()){
			int quantity= cart.get(product);
			product.productDiscription();
			System.out.println("order quantity: "+quantity);
			System.out.println("order amount: "+product.getPrice()*quantity);
		}
		System.out.println("Cart total: "+total);
	}
	

}
