package com.capgemini.test.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.dao.DaoClass;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.test.service.ServiceClass;
import com.capgemini.test.service.ServiceInterface;

public class ExecuterMain {

	public static void main(String[] args) throws IOException {
		ServiceInterface service = new ServiceClass();
		Customer cust=new Customer();
		String name;
		String address;
		String emailId;
		String mobileNo;

		// Taking input from customer
		System.out
				.println("XYZ Finance Company welcomes you \n 1.Register Customer \n 2.Exit");
		Scanner sc = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		

		String choice;
		while (true) {

			System.out.println("Enter your choice");
			choice = br.readLine();

			boolean isValid = service.validateChoice(choice);

			if (isValid) {
				break;
			} else
				System.out.println("Please enter proper choice");
		}

		if (2 == Integer.parseInt(choice)) {
			System.out.println("Thank you for your interest");

			System.exit(0);

		}

		while (true) {
			System.out.println("Enter your Name ");
			name = sc.next();
			boolean isValid = service.validateCustomerName(name);
			if (isValid)
				break;
			else
				System.out
						.println("Name should have maximum 10 characters and first letter must be capital ");
		}
		while (true) {
			System.out.println("Enter your Address");
			address = sc.next();
			boolean isValid = service.validateCustomerAddress(address);
			if (isValid)
				break;
			else
				System.out.println("First Letter should be capital");
		}
		while (true) {
			System.out.println("Enter your EmailId");
			emailId = sc.next();
			boolean isValid = service.validateCustomerEmailId(emailId);
			if (isValid)
				break;
			else
				System.out
						.println("Email Id should start with small letters then it should contain @ and . ,also it should end with alphabate");

		}
		while (true) {
			System.out.println("Enter your mobile no");
			mobileNo = sc.next();
			boolean isValid = service.validateCustomerMobileNo(mobileNo);
			if (isValid)
				break;
			else
				System.out.println("Enter proper mobile number");
		}

		Customer customer = new Customer();

		customer.setCustName(name);
		customer.setAddress(address);
		customer.setEmail(emailId);
		customer.setMobile(mobileNo);
		service.storeIntoMap(customer);
		try {
			
			service.insertCustomerDetail(customer);
		} catch (RecordNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			System.out.println(service.findCustomerDetails(customer.getCustId()));
		} catch (RecordNotFoundException e2) {
			e2.printStackTrace();
		}
		System.out.println("Customer information saved successfully"
				+ "Your Customer Id is <" + customer.getCustId() + ">");

		System.out.println("Do you wish to apply for Loan? (Yes/No)");
		String option1 = sc.next();
		String loanAmount;

		if (option1.equalsIgnoreCase("yes")) {
			while (true) {

				System.out.println("Enter the loan amount");
				loanAmount = sc.next();
				boolean isValid = service.validateLoanAmount(loanAmount);
				if (isValid)
					break;
				else
					System.out.println("You can take loan upto 99000 Rs. only");
			}

			System.out.println("Enter the loan duration");
			int loanDuration = sc.nextInt();
			Loan loan = new Loan();
			loan.setLoanAmount(Double.parseDouble(loanAmount));
			loan.setDuration(loanDuration);

			double emi = service.calculateEMI(Double.parseDouble(loanAmount),
					loanDuration);

			System.out.println("For loan amount  " + loanAmount + " and  "
					+ loanDuration
					+ "Years duration.You EMI per month will be  " + emi
					+ " you want to apply for loan now? (Yes/No)");

			option1 = sc.next();

			if (option1.equalsIgnoreCase("yes"))
				service.applyLoan(loan);
			else {
				System.out.println("Thank you for your interest");
			}
			System.out
					.println("Your Loan request is generated.Your Loan ID is "
							+ loan.getLoanID());

		} else
			System.out.println(customer);
		
		System.out.println("Enter customer Id");
		long id = sc.nextLong();
		try {
			System.out.println(service.find(id));
		} catch (RecordNotFoundException e) {
						e.printStackTrace();
		}

		sc.close();
	}
}
