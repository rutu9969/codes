package com.capgemini.test.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.AccountHolder;

public interface DaoInterface {
	
//	private Map<Integer,AccountHolder> map=new HashMap<>();	

	void storeIntoMap(AccountHolder holder);
	double showBalance();
	void deposit(double amount);
	void withdraw(double amount);
	void fundTransfer(double amount);
	void printTransaction();
	
}
