package com.capgemini.rutuja.service;

import com.capgemini.rutuja.exception.SalaryMustBeIntegerException;

public class ServiceClass implements ServiceInterface {

	@Override
	public boolean validateId(String id) {
		if (id.matches(ID_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateName(String name) {
		if (name.matches(NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public void salaryScheme(int salary){
		if (salary > 5000 && salary < 20000)
			System.out
					.println("Your designation is: System Associate \n Your Insurance scheme: Scheme C");
		else if (salary >= 20000 && salary < 40000)
			System.out
					.println("Your designation is: Programmer \n Your Insurance scheme: Scheme B");

		else if (salary >= 40000)
			System.out
					.println("Your designation is: Manager \n Your Insurance scheme: Scheme A");

		else
			System.out
					.println("Your designation is: Clerk \n Sorry there is no insurance scheme available for you");

	}

}
