package com.capgemini.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.test.utility.JdbcUtil;

public class JdbcDaoClass implements DaoInterface {

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public void insertCustomerDetail(Customer customer)
			throws RecordNotFoundException {

		connection = JdbcUtil.getConnection();

		try {
			statement = connection.prepareStatement(QuerryMapper.insertDetails);

			statement.setLong(1, customer.getCustId());
			statement.setString(2, customer.getCustName());
			statement.setString(3, customer.getMobile());
			statement.setString(4, customer.getEmail());
			statement.setString(5, customer.getAddress());

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			/*try {
				statement.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close connection object");
			}*/
		}

	}


	@Override
	public void applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		
	}
Customer cust=new Customer();
	@Override
	public Customer findCustomerDetails(long custId) throws RecordNotFoundException {
		connection = JdbcUtil.getConnection();
		try {
			statement=	connection.prepareStatement(QuerryMapper.sql);
			
			statement.setLong(1,custId);
			
			ResultSet resultSet = statement.executeQuery();
			
			if(resultSet.next()){
				
				cust.setCustId(resultSet.getLong(1));
				cust.setCustName(resultSet.getString(2));
			
				cust.setMobile(resultSet.getString(3));
				cust.setEmail(resultSet.getString(4));
				cust.setAddress(resultSet.getString(5));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cust;
	}
	@Override
	public void storeIntoMap(Customer customer) {
		// TODO Auto-generated method stub
		
	}

}
