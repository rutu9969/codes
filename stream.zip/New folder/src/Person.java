import java.io.Serializable;


public class Person implements Serializable {
	private String name;
	private int age;
//	private transient int age;  //it is used to keep data private..after use of transient keyword it will print defalut value of age 
	
	public Person() {
	}
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Name:"+name+"\tAge"+age;
	}

}
