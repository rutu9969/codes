package com.capgemini.cab.dao.test;

//import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.cab.dao.CabRequestDao;
import com.capgemini.cab.dao.ICabRequestDao;
import com.capgemini.cab.service.CabService;
import com.capgemini.cabs.bean.CabRequest;
import com.capgemini.cabs.exception.CRAException;

public class CabServcieTest {

	ICabRequestDao requestDao = null;

	@Before
	public void setUp() throws Exception {

		requestDao = new CabRequestDao();
	}

	@After
	public void tearDown() throws Exception {
		requestDao = null;
	}

	@Test
	public void testinsertCustomerDetails() {
		int requestId = 0;
		CabRequest request = 
		new CabRequest(1001, "Sujoy", "MH VS 2345",
				LocalDate.now(), "400708", "9836038745",
				"Accepted", "Gacchibowly");
		try {
			requestId = requestDao.insertCustomerDetail(request);
			Assert.assertNotNull(requestId);
		} catch (CRAException e) {

		}

	}

	@Test
	public void testinsertCustomerDetails1() {
		int requestId = 0;
		CabRequest request = new CabRequest(1001, "Sujoy", "MH VS 2345", LocalDate.now(), "400708", "9836038745",
				"Accepted", "Gacchibowly");
		try {
			requestId = requestDao.insertCustomerDetail(request);
			assertNull(requestId);
		} catch (CRAException e) {

		}

	}

}
