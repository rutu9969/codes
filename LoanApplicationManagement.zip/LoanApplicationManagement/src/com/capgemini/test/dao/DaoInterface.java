package com.capgemini.test.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.exception.RecordNotFoundException;

public interface DaoInterface {
	
	
	void storeIntoMap(Customer customer);
	void applyLoan(Loan loan);
	public void insertCustomerDetail(Customer customer) throws RecordNotFoundException;
	Customer findCustomerDetails(long custId) throws RecordNotFoundException;
	


}
