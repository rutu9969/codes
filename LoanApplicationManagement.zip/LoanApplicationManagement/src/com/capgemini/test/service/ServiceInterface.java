package com.capgemini.test.service;

import java.util.Map;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.exception.RecordNotFoundException;


public interface ServiceInterface {
	//choice for validation
	String CHOICE_PATTERN = "[1-2]{1}";
	boolean validateChoice(String choice);
	
	
	//Name pattern for validation
	String CUSTOMER_NAME_PATTERN="[A-Z][a-z]{1,9}";
	boolean validateCustomerName(String customerName);
	
//	Address pattern for validation
	String CUSTOMER_ADDRESS_PATTERN="[A-Z][a-z]{1,50}";
	boolean validateCustomerAddress(String customerAddress);
	
//	EmailId pattern for validation
	String CUSTOMER_EMAILID_PATTERN="[a-z]{1,20}[@]{1}[a-z]{1,10}[.]{1}[c,o,m]{3}";
	boolean validateCustomerEmailId(String customerEmailId);
	
//	Mobileno pattern for validation
	String CUSTOMER_MOBILE_NO_PATTERN="[7,8,9]{1}[1-9]{9}";
	boolean validateCustomerMobileNo(String customerMobileNo);
	
//	validate loan amount
	String LOAN_AMOUNT_PATTEERN="[0-9]{1,5}";
	boolean validateLoanAmount(String LoanAmount);
	double RATE_OF_INTEREST=9.5;
	
	
	void applyLoan(Loan loan);
	Customer find(long id) throws RecordNotFoundException;
	
	

	public void storeIntoMap(Customer customer);
	//public abstract
	Map<Long, Customer> displayPersons();
	
	public double calculateEMI(double amount,int duration);
	public void insertCustomerDetail(Customer customer) throws RecordNotFoundException;
	public Customer findCustomerDetails(long custId)throws RecordNotFoundException;

	
}
