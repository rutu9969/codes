package com.capgemini.rutuja.exception;

public class SalaryMustBeIntegerException extends Exception{
	
	
	public SalaryMustBeIntegerException() {
	}

	public SalaryMustBeIntegerException(String msg) {
		super();
	}

}
