
public class Shoe extends Product{
	private int size;

	public Shoe(int codeName, String productName, double price, int stock,int size) {
		super(codeName, productName, price, stock);
		this.size=size;
	}
	public void shoeDetails(){
		super.productDiscription();
		System.out.println("size: "+size);
	}

	

}
