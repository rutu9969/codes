package com.capgemini.test.dao;

public interface QuerryMapper {
	
	String insertDetails =
			"insert into cust_details"
			+ "(custId,custName,mobile,email,address)"+"Values"
			+ "(?,?,?,?,?)";
			
		/*	Insert into patient values
			(124,�patient 2�,13,9898989898,�unwell�,sysdate
		*/	
			
	String sql =
			"select * from cust_details where CUSTID=?";
}
