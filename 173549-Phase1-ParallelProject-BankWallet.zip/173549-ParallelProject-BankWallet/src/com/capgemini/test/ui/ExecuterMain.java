package com.capgemini.test.ui;

import java.awt.Choice;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.test.bean.AccountHolder;
import com.capgemini.test.service.ServiceClass;
import com.capgemini.test.service.ServiceInterface;

public class ExecuterMain {
	public static void main(String[] args) throws IOException {
		AccountHolder holder = new AccountHolder();
		ServiceInterface service = new ServiceClass();
		String name;
		String address;
		String mobile;
		String age;
		String choice;
		String emailId;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		Scanner sc = new Scanner(System.in);
		System.out
				.println("Welcome\n Do you want to open an account? \n 1.yes \n 2.No");
		while (true) {
			choice = sc.next();

			boolean isValid = service.validateChoice(choice);
			if (isValid)
				break;
			else
				System.out.println("Please Enter proper choice ");

		}
		if (2 == Integer.parseInt(choice)) {

			System.out.println("Thank you ");
			System.exit(0);

		}

		while (true) {
			System.out.println("Enter your Name ");
			name = br.readLine();
			boolean isValid = service.validateCustomerName(name);
			if (isValid)
				break;
			else
				System.out
						.println("Name should have maximum 10 characters and first letter must be capital ");
		}
		while (true) {
			System.out.println("Enter your Address");
			address = sc.next();
			boolean isValid = service.validateCustomerAddress(address);
			if (isValid)
				break;
			else
				System.out.println("First Letter should be capital");
		}
		while (true) {
			System.out.println("Enter your EmailId");
			emailId = sc.next();
			boolean isValid = service.validateCustomerEmailId(emailId);
			if (isValid)
				break;
			else
				System.out
						.println("Email Id should start with small letters then it should contain @ and . ,also it should end with alphabate");

		}
		while (true) {
			System.out.println("Enter your mobile no");
			mobile = sc.next();
			boolean isValid = service.validateCustomerMobileNo(mobile);
			if (isValid)
				break;
			else
				System.out.println("Please enter proper mobile number");
		}

		holder.setHolderName(name);
		holder.setHolderAddress(address);
		holder.setHolderMobile(mobile);
		service.storeIntoMap(holder);

		System.out
				.println("Your details are saved and your account number is : "
						+ holder.getAccountNumber());
		System.out.println("Welcome to Rutuja bank wallet \n Our bank provides following services");


		while (true) {

			System.out.println("Enter the coice you want to go for ");
			System.out.println("1.Show Balance");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Print Transaction");
			System.out.println("6.Exit");
			int choice1;
			choice1 = sc.nextInt();
			switch (choice1) {
			case 1:
				System.out.println("....Show Balance....");
				System.out.println("Your account balance is :"
						+ service.showBalance());
				// service.showBalance();
				break;
			case 2:
				System.out.println("....Deposit....");
				System.out
						.println("Enter the amount You want to deposit in your account");
				double amount = sc.nextDouble();
				service.deposit(amount);
				break;
			case 3:
				System.out.println("....Withdraw....");
				System.out
						.println("Enter the amount You want to withdraw from your account");
				amount = sc.nextDouble();
				service.withdraw(amount);
				break;
			case 4:
				System.out.println("....Fund transfer....");
				System.out
						.println("Enter the Account Number in which you want to transfer fund amount");
				int accountNumber = sc.nextInt();

				System.out
						.println("Enter the fund amount you want to transfer in another account");
				amount = sc.nextDouble();
				service.fundTransfer(amount);
				break;
			case 5:
				System.out.println("....Print Transaction...");
				service.printsummary();
				break;
			case 6:
				System.out.println("Thank You");
				System.exit(0);

			default:
				System.out.println("You have entered wrong choice");

			}

		}

	}
}
