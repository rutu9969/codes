
public class EmptyStockException {
	public EmptyStockException(){
		super();
	}
	public EmptyStockException(String message){
		super();
		System.out.println(message);
	}
	

}
