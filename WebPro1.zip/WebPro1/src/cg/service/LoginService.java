package cg.service;

import java.util.Base64;
import java.util.Base64.Encoder;

import cg.bean.LoginBean;
import cg.dao.ILoginDao;
import cg.dao.LoginDao;

public class LoginService implements ILoginService{
	private ILoginDao dao;
	public LoginService() {
		dao=new LoginDao();
	}

	@Override
	public boolean authenticate(LoginBean login) {
		Encoder encoder=Base64.getEncoder();
		
		byte[] password=encoder.encode(login.getPassword().getBytes());
		login.setPassword(new String(password));
		return dao.validate(login);
	}

}
