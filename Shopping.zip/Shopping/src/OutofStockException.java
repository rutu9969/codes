
public class OutofStockException extends Exception {
	
	public OutofStockException(){
		super();
	}

	public OutofStockException(String message){
		super();
		System.out.println(message);
	}
}
