package com.capgemini.rutuja.service;

public interface ServiceInterface {
	
	//to validate id
	String ID_PATTERN="[0-9]{1,10}";
	boolean validateId(String id);
	
	//to validate name
	String NAME_PATTERN="[a-z]{1,60}";
	boolean validateName(String name);
	
	void salaryScheme(int salary);

}
