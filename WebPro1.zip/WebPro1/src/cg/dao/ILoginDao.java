package cg.dao;

import cg.bean.LoginBean;

public interface ILoginDao {
	boolean validate(LoginBean login);
	

}
