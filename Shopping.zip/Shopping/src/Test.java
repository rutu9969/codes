
public class Test {

	public static void main(String[] args) throws OutofStockException {
		
		Shoe s1= new Shoe(123, "BATA",10000 , 8, 3);
		Shoe s2= new Shoe(123, "BATA",10000 , 8, 3);
		Watch w= new Watch(456, "gshock", 50000,12, "chrono");
		
		ShoppingCart sc= new ShoppingCart();
        sc.addItem(s1, 5);
        sc.checkout();
        sc.updateQuantity(s1, 7);
        sc.checkout();
    	//sc.removeItem(s1);
    	
//		
//		sc.addItem(w, 2);
//		sc.checkout();
//		sc.addItem(s2, 2);
	}
}
