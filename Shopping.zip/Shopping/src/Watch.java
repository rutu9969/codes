public class Watch extends Product {
	private String type;

	public Watch(int codeName, String productName, double price, int stock,
			String type) {
		super(codeName, productName, price, stock);
		this.type = type;
	}

	public void watchDetails() {
		super.productDiscription();
		System.out.println("Type"+type);
	}

}
