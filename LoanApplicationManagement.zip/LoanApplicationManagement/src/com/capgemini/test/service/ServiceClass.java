package com.capgemini.test.service;

import java.util.Map;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.bean.Loan;
import com.capgemini.test.dao.DaoClass;
import com.capgemini.test.dao.DaoInterface;
import com.capgemini.test.dao.JdbcDaoClass;
import com.capgemini.test.exception.RecordNotFoundException;

public class ServiceClass implements ServiceInterface {

	@Override
	public boolean validateChoice(String choice) {
		if(choice.matches(CHOICE_PATTERN))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateCustomerName(String customerName) {
		

		if (customerName.matches(CUSTOMER_NAME_PATTERN))
			return true;
		else
			return false;

	}

	@Override
	public boolean validateCustomerAddress(String customerAddress) {
		if (customerAddress.matches(CUSTOMER_ADDRESS_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateCustomerEmailId(String customerEmailId) {
		if (customerEmailId.matches(CUSTOMER_EMAILID_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateCustomerMobileNo(String customerMobileNo) {
		if (customerMobileNo.matches(CUSTOMER_MOBILE_NO_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateLoanAmount(String LoanAmount) {
		if (LoanAmount.matches(LOAN_AMOUNT_PATTEERN))
			return true;
		else
			return false;
	}

	DaoClass dao = new DaoClass();

	@Override
	public void storeIntoMap(Customer customer) {
		dao.storeIntoMap(customer);
	}

	@Override
	public Map<Long, Customer> displayPersons() {
		return dao.displayCustomer();
	}

	@Override
	public void applyLoan(Loan loan) {
		dao.applyLoan(loan);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		return amount * RATE_OF_INTEREST * (1 + RATE_OF_INTEREST) * duration
				/ ((1 + RATE_OF_INTEREST) * duration - 1);
	}

	@Override
	public Customer find(long id) throws RecordNotFoundException {
		return dao.find(id);
		
	}
	JdbcDaoClass jdao=new JdbcDaoClass();

	@Override
	public void insertCustomerDetail(Customer customer)
			throws RecordNotFoundException {
		
		 jdao.insertCustomerDetail(customer);
	}

	@Override
	public Customer findCustomerDetails(long custId)throws RecordNotFoundException {
		return jdao.findCustomerDetails(custId);
	}

	


	



}
