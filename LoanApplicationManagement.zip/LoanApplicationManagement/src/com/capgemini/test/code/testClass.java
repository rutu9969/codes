package com.capgemini.test.code;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.test.bean.Customer;
import com.capgemini.test.dao.DaoClass;
import com.capgemini.test.exception.RecordNotFoundException;

public class testClass {
	DaoClass obj=null;
	@Before
	public void beforeMethod() throws Exception{
		obj=new DaoClass();
	}
	@After
	public void afterMethod() throws Exception{
		obj=null;
	}
	@Test
	public void testValidateCustomer(){
		Customer cust=new Customer();
		Customer reqCustomer=new Customer();
		cust.setCustName("Rutuja");
		cust.setAddress("Pune");
		cust.setEmail("xyz@gmail.com");
		cust.setMobile("768976655");
		obj.storeIntoMap(cust);
		
		long id= cust.getCustId();
		try {
			reqCustomer =obj.find(id);
			Assert.assertNotNull(reqCustomer);
			System.out.println("test passed");
		} catch (RecordNotFoundException e) {
			
			System.out.println(e);
		}
		
		
	}
	@Test
	public void testInValidateCustomer(){
		Customer cust=new Customer();
		Customer reqCustomer=new Customer();
		cust.setCustName("Rutuja");
		cust.setAddress("Pune");
		cust.setEmail("xyz@gmail.com");
		cust.setMobile("768976655");
		obj.storeIntoMap(cust);
		

		try {
			reqCustomer =obj.find(10);
			Assert.assertNotNull(reqCustomer);
			//System.out.println("test passed");
		} catch (RecordNotFoundException e) {
			
			System.out.println(e);
		}
	}

}
